# Rocketperf Windows x64运行包

固定Git提交：27e29facf4ba12cc733a178e02c41e6ba968dc8f

项目详细解读：[docs/project-guide.md](docs/project-guide.md)。数据许可见DATA-SOURCES.md和third_party。

源码构建需要Windows GCC/CMake/Ninja；exe运行只需Windows系统库。没有Python/Fortran生产依赖。

```powershell
./rocketperf.exe run cases/benchmarks/air_mach2_vacuum.ini
./rocketperf.exe study propellants --case cases/research/propellant_comparison.ini
./rocketperf.exe combustion frozen-rp1 cea-v3.3.4-rp1-o2l-assigned-v1 liquid RP-1 'O2(L)' 10000000 2.6 298.15 90.170 10 0 0.01
./rocketperf.exe run tests/fixtures/overexpanded.ini
$LASTEXITCODE
```

拒绝算例退出4、stdout为空；成功输出JSON。阶段方法结果不可贴真实发动机性能标签。

完整研究资料与维护记录见私有仓库。PACKAGE.json核对逐文件SHA256，Release外部SHA256SUMS.txt核对ZIP来源。
