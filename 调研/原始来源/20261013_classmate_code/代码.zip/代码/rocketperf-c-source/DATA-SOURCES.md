# 数据与许可

固定提交：27e29facf4ba12cc733a178e02c41e6ba968dc8f

NASA9与指定CH4(L)/O2(L)/RP-1常量提取自NASA CEA v3.3.4；上游Apache-2.0 LICENSE/NOTICE随包。

单相CH4/O2查表来自CoolProp7.1.0 HEOS离线参考，MIT和书目随包；C运行没有上游求解库依赖。

完整参数、参考原文及哈希保留于私有仓库：https://github.com/2725238326/rocketperf-course-research/tree/27e29facf4ba12cc733a178e02c41e6ba968dc8f

项目自有代码尚未选择对外许可证。本包供授权小组维护和课程接收，未声明公开再分发许可。

包内SVG保留布局/文字，移除了指向完整仓库的局部跳转；原图/生成源在仓库保留。
