# Rocketperf 纯C源码包

固定Git提交：27e29facf4ba12cc733a178e02c41e6ba968dc8f

项目详细解读：[docs/project-guide.md](docs/project-guide.md)。数据许可见DATA-SOURCES.md和third_party。

源码构建需要Windows GCC/CMake/Ninja；exe运行只需Windows系统库。没有Python/Fortran生产依赖。

```powershell
cmake -S . -B build/cmake -G Ninja -DCMAKE_C_COMPILER=gcc -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON -DROCKETPERF_ENABLE_PYTHON_TESTS=OFF
cmake --build build/cmake
ctest --test-dir build/cmake --output-on-failure
```

拒绝算例退出4、stdout为空；成功输出JSON。阶段方法结果不可贴真实发动机性能标签。

完整研究资料与维护记录见私有仓库。PACKAGE.json核对逐文件SHA256，Release外部SHA256SUMS.txt核对ZIP来源。
